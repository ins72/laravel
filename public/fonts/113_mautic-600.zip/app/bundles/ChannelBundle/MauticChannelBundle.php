<?php

namespace Mautic\ChannelBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MauticChannelBundle extends Bundle
{
}

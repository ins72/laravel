<?php

namespace Mautic\WebhookBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MauticWebhookBundle extends Bundle
{
}

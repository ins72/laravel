<?php

namespace Mautic\DynamicContentBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MauticDynamicContentBundle extends Bundle
{
}

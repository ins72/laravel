<?php

namespace Mautic\StatsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MauticStatsBundle extends Bundle
{
}

<?php

namespace Mautic\PluginBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MauticPluginBundle extends Bundle
{
}

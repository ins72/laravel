<?php

namespace Mautic\FormBundle\Exception;

class FileValidationException extends \Exception
{
}

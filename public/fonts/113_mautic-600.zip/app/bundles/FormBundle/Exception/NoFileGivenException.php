<?php

namespace Mautic\FormBundle\Exception;

class NoFileGivenException extends \Exception
{
}

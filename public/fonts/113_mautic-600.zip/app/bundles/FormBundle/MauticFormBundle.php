<?php

namespace Mautic\FormBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MauticFormBundle extends Bundle
{
}

<?php

declare(strict_types=1);

namespace Mautic\FormBundle\Collection;

/**
 * @extends \ArrayIterator<string,FieldCollection>
 */
final class MappedObjectCollection extends \ArrayIterator
{
}

<?php

namespace Mautic\FormBundle\Entity;

use Mautic\CoreBundle\Entity\CommonRepository;

/**
 * @extends CommonRepository<Action>
 */
class ActionRepository extends CommonRepository
{
}
